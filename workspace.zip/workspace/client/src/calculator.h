// calculator.h
#ifndef CALCULATOR_H
#define CALCULATOR_H

#define BUFFER_SIZE 256

#endif
