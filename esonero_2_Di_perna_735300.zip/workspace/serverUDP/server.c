
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include "calculator.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define PORT 12345

void winsock_cleaner() {
#if defined WIN32
	WSACleanup();
#endif
}



int main() {
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int res = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (res != 0) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif
	// Create socket
	int client_socket;
	if ((client_socket =  socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) <0) {
		perror("Error creating socket");
		closesocket(client_socket);
		winsock_cleaner();
		_exit(0);
	}


	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	unsigned int client_addr_len = sizeof(client_addr);
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");



	printf("Server is running...\n-------------------------------------\n");
	// Bind the socket
	if (bind(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
		perror("Error binding socket");
		closesocket(client_socket);
		winsock_cleaner();
		_exit(0);
	}

	char buffer[BUFFER_SIZE];
	int num1, num2;
	int result;
	char operation;
	while (1) {
		// Handle client operations

		memset(buffer, 0, BUFFER_SIZE);

		// Read operation and numbers from client
		if ((recvfrom(client_socket, buffer, BUFFER_SIZE, 0,(struct sockaddr *)&client_addr, &client_addr_len)) < 0) {
			perror("Error receiving data from client");
			break;

		}

		//Printing client's address, port and message received
		struct hostent *client_host = gethostbyaddr((char *)&client_addr.sin_addr.s_addr, sizeof(client_addr.sin_addr.s_addr), AF_INET);
		printf("Operazione richiesta dal client %s con IP %s:%d ->  %s \n", client_host->h_name, inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port), buffer);

		// Parse data

		sscanf(buffer, "%c %d %d", &operation, &num1, &num2);
		memset(buffer, 0, BUFFER_SIZE);
		// Perform the requested operation
		switch (operation) {
		case '+':
			result = add(num1, num2);
			break;
		case 'x':
			result = mult(num1, num2);
			break;
		case '-':
			result = sub(num1, num2);
			break;
		case '/':
			result = division(num1, num2);
			break;
		}

		// Send the result to the client
		sprintf(buffer, "%d %c %d = %d", num1,operation,num2,result);

		if (sendto(client_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&client_addr, sizeof(client_addr)) < 0 ) {
			perror("Error sending data to client");
			closesocket(client_socket);
			winsock_cleaner();
			_exit(0);
		}
		printf("Risultato spedito al client: %s\n-----------------------------------------\n", buffer);
		memset(buffer, 0, BUFFER_SIZE);
	}



	return 0;
}

int add(int i1, int i2){
	return i1+i2;
}
int sub(int i1, int i2){
	return i1-i2;
}
int mult(int i1,int i2){
	return i1*i2;
}
int division(int i1,int i2){
	return i1/i2;
}
