// calculator.h
#ifndef CALCULATOR_H
#define CALCULATOR_H

#define BUFFER_SIZE 256

// Function declarations
int add(int a, int b);
int mult(int a, int b);
int sub(int a, int b);
int division(int a, int b);

#endif
