#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include "calculator.h"

#define DEFAULT_IP "127.0.0.1"
#define DEFAULT_PORT 56700
#define BUFFER_SIZE 256


void winsock_cleaner() {
#if defined WIN32
	WSACleanup();
#endif
}

int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int res = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (res != 0) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif
	char buffer[BUFFER_SIZE];
	char operation;
	char *name = DEFAULT_IP;
	int port = DEFAULT_PORT;
	int num1, num2;
	int server_socket;

	// Parsing arguments to get server ip and port
	if(argc > 1){
		name = strtok(argv[1], ":");
		port = atoi(strtok(NULL, ":"));
	}

	struct hostent *host = gethostbyname(name);
	if (host == NULL)
	{
		winsock_cleaner();
		perror("Error getting host");
		_exit(0);
	}
	printf("Server found with name: %s\n IP: %s \nport: %d\n", name, inet_ntoa(*(struct in_addr *)host->h_addr), port);

	// Create socket
	if ((server_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) <0) {
		closesocket(server_socket);
		winsock_cleaner();
		perror("Error creating socket");
		_exit(0);
	}

	// Set up server address struct
	struct sockaddr_in server_addr;
	unsigned int server_addr_len = sizeof(server_addr);
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr = *((struct in_addr *)host->h_addr);
	server_addr.sin_port = htons(port);



	// Send and receive data

	while (1) {
		memset(buffer, 0, BUFFER_SIZE);
		// Read operation and numbers from user
		printf("Enter operation and two numbers (e.g., + 23 45): ");
		fgets(buffer, sizeof(buffer), stdin);
		sscanf(buffer, "%c %d %d", &operation, &num1, &num2);

		// Check if the client should terminate
		if (operation == '=') {
			break;
		}

		// Send data to server
		if (sendto(server_socket, buffer, strlen(buffer), 0,(struct sockaddr *)&server_addr, server_addr_len) != strlen(buffer)) {
			closesocket(server_socket);
			winsock_cleaner();
			perror("Error sending data to server");
			_exit(0);
		}
		memset(buffer, 0, BUFFER_SIZE);

		// Receive result from server
		if (recvfrom(server_socket, buffer, sizeof(buffer), 0,(struct sockaddr *)&server_addr,&server_addr_len) == -1) {
			closesocket(server_socket);
			winsock_cleaner();
			perror("Error receiving data from server");
			_exit(0);
		}

		// Parse and print result
		//sscanf(buffer, "%s", &result);
		printf("Result from server: %s\n", buffer);

	}

	// Close the socket
	closesocket(server_socket);
	winsock_cleaner();

	return 0;
}
